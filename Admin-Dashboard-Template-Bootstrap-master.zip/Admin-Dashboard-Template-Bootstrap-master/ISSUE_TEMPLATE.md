### Expected behavior

### Actual behavior

### Your working environment and MDB template version information

### Resources (screenshots, code snippets etc.)

For every **question of technical nature**, in order to get the most detailed answer as soon as possible, ask on our dedicated [Support Forum](https://mdbootstrap.com/support/)
